# Devdata placeholder

This directory should contain local development data.

This data should not be used in actual Robocorp App run but can be
used when you are building and debugging your entrypoints and robots.

## What to put here?

- Local work item data
- Local environment variables (in JSON format)
- Local custom data files (\*.csv, etc.)
